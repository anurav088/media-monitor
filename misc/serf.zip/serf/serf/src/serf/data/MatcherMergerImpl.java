package serf.data;

import org.apache.commons.codec.language.DoubleMetaphone;
import org.apache.commons.text.similarity.LevenshteinDistance;

import java.io.ByteArrayInputStream;
import java.util.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;

public class MatcherMergerImpl implements MatcherMerger {

    private double nameThreshold;

    public MatcherMergerImpl(Properties properties) {
        this.nameThreshold = Double.parseDouble(properties.getProperty("NameThreshold", "0.33"));

        System.out.println("Name Similarity Threshold: " + nameThreshold);
    }

    
    
    
    
    
    private DoubleMetaphone doubleMetaphone = new DoubleMetaphone();
    private LevenshteinDistance levenshteinDistance = new LevenshteinDistance();






    @Override
    public boolean match(Record r1, Record r2) {
        // Use your custom getName method
        String name1 = getName(r1);
        String name2 = getName(r2);

        // Implement your fuzzy matching logic here
        return name1 != null && name2 != null && fuzzyMatchPer(name1, name2);
    }
    @Override
    public Record merge(Record r1, Record r2) {
        // Use the custom getName method to get names
        String name1 = getName(r1);
        String name2 = getName(r2);

        // Simplified merge, just concatenating the names
        String mergedName = (name1 != null ? name1 : "") + " " + (name2 != null ? name2 : "");
        
        // Create a new Attribute set or map (assuming your Record class uses attributes)
        Map<String, Attribute> attributes = new HashMap<>(r1.getAttributes());
        attributes.put("name", new Attribute("name", mergedName));  // Assuming an Attribute class exists

        // Return a new Record with the merged name and attributes
        return new Record(r1.getConfidence(), attributes);
    }

    // Custom getName function that parses XML content
        private String getName(Record r1) {
        // Assuming r1.getAttributes() or some method provides XML content as a string
        String xmlContent = r1.toString(); // Adjust this if r1 stores XML differently
        
        // Print the XML content for debugging
        System.out.println("XML Content: " + xmlContent);
        
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            ByteArrayInputStream input = new ByteArrayInputStream(xmlContent.getBytes("UTF-8"));
            Document doc = builder.parse(input);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("attribute");
            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    if (eElement.getAttribute("name").equals("name")) {
                        return eElement.getElementsByTagName("value").item(0).getTextContent();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;  // Return null if name is not found or any exception occurs
    }


    private boolean abbreviationsCheck(String name1, String name2) {
        List<Character> initials1 = new ArrayList<>();
        for (char c : name1.toUpperCase().toCharArray()) {
            initials1.add(c);
        }
        List<Character> initials2 = new ArrayList<>();
        for (char c : name2.toUpperCase().toCharArray()) {
            initials2.add(c);
        }
        Collections.sort(initials1);
        Collections.sort(initials2);
        return initials1.equals(initials2);
    }

    private boolean fuzzyCheck(String a, String b) {
        if (a.equals(b)) return true;
        if (doubleMetaphone.doubleMetaphone(a).equals(doubleMetaphone.doubleMetaphone(b))) return true;
        if (a.charAt(0) == b.charAt(0)) {
            if ((a.length() <= 6 && a.length() > 3) && (levenshteinDistance.apply(a, b) <= 1)) return true;
            else if (a.length() > 6 && levenshteinDistance.apply(a, b) <= 2) return true;
        }
        return false;
    }

    private boolean exactMatchPer(String name1, String name2) {
        List<String> wordList1 = Arrays.asList(name1.toLowerCase().split("\\s+"));
        List<String> wordList2 = Arrays.asList(name2.toLowerCase().split("\\s+"));
        return wordList1.equals(wordList2);
    }

    private boolean fuzzyMatchPer(String name1, String name2) {
        List<String> wordList1 = new ArrayList<>(Arrays.asList(name1.toLowerCase().split("\\s+")));
        List<String> wordList2 = new ArrayList<>(Arrays.asList(name2.toLowerCase().split("\\s+")));

        wordList1.removeIf(w -> wordList2.stream().anyMatch(v -> fuzzyCheck(w, v)));
        wordList2.removeIf(w -> wordList1.stream().anyMatch(v -> fuzzyCheck(v, w)));

        return wordList1.isEmpty() && wordList2.isEmpty();
    }
}
