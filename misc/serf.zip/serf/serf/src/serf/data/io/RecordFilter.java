package serf.data.io;

import serf.data.*;

public class RecordFilter {

	//don't filter anything...
	public boolean includeRecord(serf.data.Record r)
	{
		return true;
	}
	
		
	
}
