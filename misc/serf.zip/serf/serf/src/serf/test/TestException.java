package serf.test;

public class TestException extends Exception {
	
	public TestException(String s){
		super(s);
	}
}
