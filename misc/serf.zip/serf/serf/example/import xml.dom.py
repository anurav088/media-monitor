import xml.dom.minidom

# Read the XML file
with open("products.xml", "r") as file:
    xml_data = file.read()

# Parse and pretty-print the XML
dom = xml.dom.minidom.parseString(xml_data)
pretty_xml = dom.toprettyxml()

# Save the cleaned XML
with open("output_cleaned.xml", "w") as file:
    file.write(pretty_xml)
